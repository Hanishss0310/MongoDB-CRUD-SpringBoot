package com.example.mongoc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mongoc2Application {

	public static void main(String[] args) {
		SpringApplication.run(Mongoc2Application.class, args);
	}

}
