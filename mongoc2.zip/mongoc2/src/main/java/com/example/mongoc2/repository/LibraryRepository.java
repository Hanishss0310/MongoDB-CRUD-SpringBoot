package com.example.mongoc2.repository;

import com.example.mongoc2.entity.Library;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface LibraryRepository extends MongoRepository<Library, Integer> {

}
