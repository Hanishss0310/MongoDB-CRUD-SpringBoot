package com.example.mongoc2.entity;


import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Library {

    private int ID;
    private  String Title;

    public Library() {
        super();
    }

    public Library(int ID, String title) {
        this.ID = ID;
        Title = title;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    @Override
    public String toString() {
        return "Library{" +
                "ID=" + ID +
                ", Title='" + Title + '\'' +
                '}';
    }
}
