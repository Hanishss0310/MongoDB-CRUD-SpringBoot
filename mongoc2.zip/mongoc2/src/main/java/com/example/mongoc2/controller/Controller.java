package com.example.mongoc2.controller;


import com.example.mongoc2.entity.Library;
import com.example.mongoc2.repository.LibraryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Controller {

    @Autowired
    private LibraryRepository repo;

    @PostMapping("/post")
    public String adddata(@RequestBody Library library){
        this.repo.save(library);
        return  "Data added successfully";
    }

    @GetMapping("/getdata")
    public List<Library> getdata(){
    return (List<Library>) this.repo.findAll();
    }

    @PutMapping("/put")
    public String updatedata(@PathVariable int ID,@RequestBody Library library){
        this.repo.save(library);
        return "Updated successfully";
    }

    @DeleteMapping("/delete{ID}")
    public String deletedata(@PathVariable int ID){
        this.repo.deleteById(ID);
        return "Data Deleted Successfully";
    }
}
